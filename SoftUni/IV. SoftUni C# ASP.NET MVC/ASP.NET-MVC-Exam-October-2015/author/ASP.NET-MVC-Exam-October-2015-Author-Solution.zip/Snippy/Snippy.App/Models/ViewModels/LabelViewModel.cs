﻿namespace Snippy.App.Models.ViewModels
{
    public class LabelViewModel : ConciseLabelViewModel
    {
        public int SnippetsCount { get; set; }
    }
}