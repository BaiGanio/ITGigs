﻿namespace Snippy.App.Models.ViewModels
{
    public class LanguageViewModel
    {
        public int Id { get; set; }

        public string Name { get; set; }
    }
}