﻿namespace Snippy.App.Models.ViewModels
{
    public class ConciseLabelViewModel
    {
        public int Id { get; set; }

        public string Text { get; set; }
    }
}